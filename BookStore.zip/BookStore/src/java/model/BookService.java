/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.util.List;
import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author majoviveros
 */
public class BookService {
    public final static BookService instance = new BookService();

   private static final EntityManagerFactory emf = Persistence.createEntityManagerFactory("BookStorePU");
   
   public List<Book> getBooks(){
       List<Book> books = new ArrayList<>();
       
       EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            books = em.createQuery("SELECT b FROM Book b", Book.class).getResultList();
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            em.close();
        }
       
       return books;
   }
   
   public void addBook(String isbn, String title, String author, String year, String publisher, int quantity) {
       Book b = new Book(isbn, title, author, year, publisher, quantity); 
       EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(b);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            em.close();
        }
  }
   
   public void removeBook(int id){
       EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            Book b = em.find(Book.class, id);
            em.remove(b);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            em.close();
        }
   }
   
   public void updateBook(int id, String isbn, String title, String author, String year, String publisher, int quantity){
       EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            Book b = em.find(Book.class, id);
            b.setIsbn(isbn);
            b.setTitle(title);
            b.setAuthor(author);
            b.setYear(year);
            b.setPublisher(publisher);
            b.setQuantity(quantity);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            em.close();
        }
   }
   
   public Book getBookById(int id) {
        Book b = null;
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            b = em.find(Book.class, id);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            em.close();
        }
        return b;
    }
}
