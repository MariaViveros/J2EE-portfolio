package controller;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import model.Problem;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.AuthenticationService;
import model.User;

/**
 *
 * @author Cheng Thao
 */
@WebServlet(urlPatterns = {"/MathServlet"})
public class MathServlet extends HttpServlet {
    
    private String getCookieValue(HttpServletRequest req, String name) {
        Cookie[] cookies = req.getCookies();
        for (Cookie c : cookies) {
            if (c.getName().equals(name)) {
                return c.getValue();
            }
        }
        return null;
    }

    private Cookie getCookie(HttpServletRequest req, String name) {
        Cookie[] cookies = req.getCookies();
        for (Cookie c : cookies) {
            if (c.getName().equals(name)) {
                return c;
            }
        }
        return null;
    }
    
    private char [] ops = {'+', '+', '*', '/'};
    
    private char randOp(){
        Random r = new Random();
        return ops[r.nextInt(ops.length)];
    }
    
    private int randOperand(){
        Random r = new Random();
        return r.nextInt(100);
    }
    
    private Problem randProblem(){
        return new Problem(randOp(), randOperand(), randOperand(), 0);
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        List<Problem> problems = (List<Problem>) request.getSession().getAttribute("problems");
        Problem prevProblem = (Problem) request.getSession().getAttribute("problem");
        String url = "/index.jsp";
        
        if (request.getSession().getAttribute("user") == null) {
            Cookie[] cookies = request.getCookies();
            String email = "";
            if (cookies != null) {
            for (Cookie c : cookies) 
                if (c.getName().equals("email")) 
                    email = c.getValue();
            }
            User userObject = AuthenticationService.instance().getUser(email);
            request.getSession().setAttribute("user", userObject);
            if (userObject == null)  url = "/WEB-INF/login.jsp";
        }
        
        
        if (problems == null){
            problems = new ArrayList<>();
            request.getSession().setAttribute("problems", problems);
        }
        
        if (prevProblem != null) {
            problems.add(prevProblem);
        
            if (request.getParameter("submit")!=null){
                prevProblem.setUserAnswer(Integer.parseInt(request.getParameter("userAnswer")));
            }
        }
        
        
        
        Problem nextProblem = randProblem();
        request.getSession().setAttribute("problem", nextProblem);
        
        getServletContext().getRequestDispatcher(url).forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
