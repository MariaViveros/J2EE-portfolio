package model;

public class AuthenticationService {
	private final User[] users;
	private static AuthenticationService instance;
	public static AuthenticationService instance(){
		return instance == null ? instance = new AuthenticationService() : instance;
	}
	
	private AuthenticationService() {
		users = new User[]{
		  new User("Cheng Thao", "cheng.thao@saintpaul.edu", "Pa$$w0rd"),
			new User("Mike Brown", "mbrown@gmail.com", "Pa$$w0rd"),
			new User("Daniel Carter", "carter@gmail.com", "Pa$$w0rd")
		};
	}
	
	public boolean authenticate(String email, String password){
		for(User user:users)
			if (user.getEmail().equals(email) && 
                                user.getPassword().equals(password))
				return true;
		
		return false;
	}
	
	public User getUser(String email){
		for(User u:users) if (u.getEmail().equals(email)) return u;
		return null;
	}
	
}


