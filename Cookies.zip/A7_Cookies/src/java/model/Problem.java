package model;


/**
 *
 * @author Cheng Thao
 */
public class Problem {
    
    private char op;
    private int left;
    private int right;
    private int userAnswer;

    public Problem() {
    }

    public Problem(char op, int left, int right, int userAnswer) {
        this.op = op;
        this.left = left;
        this.right = right;
    }

    public char getOp() {
        return op;
    }

    public void setOp(char op) {
        this.op = op;
    }

    public int getLeft() {
        return left;
    }

    public void setLeft(int left) {
        this.left = left;
    }

    public int getRight() {
        return right;
    }

    public void setRight(int right) {
        this.right = right;
    }
    
    public int getSolution(){
        switch(getOp()){
            case '+': return getLeft() + getRight();
            case '-': return getLeft() - getRight();
            case '*': return getLeft() * getRight();
            default: return getLeft() / getRight();
        }
    }

    public int getUserAnswer() {
        return userAnswer;
    }

    public void setUserAnswer(int userAnswer) {
        this.userAnswer = userAnswer;
    }
}
