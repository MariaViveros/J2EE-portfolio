/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package todo.model;
import java.util.List;
import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author majoviveros
 */
public class TodoService {
   
   public final static TodoService instance = new TodoService();

   private static final EntityManagerFactory emf = Persistence.createEntityManagerFactory("ToDoList_JPAPU");

   public List<Todo> getTodos(){
       List<Todo> todos = new ArrayList<>();
       
       EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            todos = em.createQuery("SELECT t FROM Todo t", Todo.class).getResultList();
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            em.close();
        }
       
       return todos;
   }
   
   public void addTodo(String description, boolean done) {
       Todo t = new Todo(description, done); 
       EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(t);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            em.close();
        }
  }
   
   public void removeTodo(int id){
       EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            Todo t = em.find(Todo.class, id);
            em.remove(t);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            em.close();
        }
   }
   
   public void updateTodo(int id, String description, boolean done){
       EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            Todo t = em.find(Todo.class, id);
            t.setDescription(description);
            t.setDone(done);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            em.close();
        }
   }

    public Todo getTodoById(int id) {
        Todo t = null;
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            t = em.find(Todo.class, id);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            em.close();
        }
        return t;
    }
   
   
}
