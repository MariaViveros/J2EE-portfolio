/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.util.List;
import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author majoviveros
 */
public class TodoService {
   public final static TodoService instance = new TodoService();

   private static final EntityManagerFactory emf = Persistence.createEntityManagerFactory("FinalProjectPU");
   
   public List<Todo> getTodos(){
       List<Todo> todos = new ArrayList<>();
       
       EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            todos = em.createQuery("SELECT t FROM Todo t", Todo.class).getResultList();
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            em.close();
        }
       
       return todos;
   }
   
   public void addTodo(String title, String description, String category, boolean complete) {
       Todo t = new Todo(title, description, category, complete); 
       EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(t);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            em.close();
        }
  }
   
   public void removeTodo(int id){
       EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            Todo t = em.find(Todo.class, id);
            em.remove(t);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            em.close();
        }
   }
   
   public void updateTodo(int id, String title, String description, String category, boolean complete){
       EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            Todo t = em.find(Todo.class, id);
            t.setDescription(description);
            t.setDone(complete);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            em.close();
        }
   }
   
   public Todo getTodoById(int id) {
        Todo t = null;
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            t = em.find(Todo.class, id);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            em.close();
        }
        return t;
    }
    
}
