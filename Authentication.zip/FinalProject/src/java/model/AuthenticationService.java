/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.util.List;
import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author majoviveros
 */
public class AuthenticationService {
    
   
    public static AuthenticationService instance;
    public static AuthenticationService instance(){
		return instance == null ? instance = new AuthenticationService() : instance;
	}

    private static final EntityManagerFactory emf = Persistence.createEntityManagerFactory("FinalProjectPU");
   
        //private final User[] users;
    List<User> users = new ArrayList<>();
       
    public List<User> getUsers(){
       
       
       EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            users = em.createQuery("SELECT u FROM User u", User.class).getResultList();
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            em.close();
        }
       
       return users;
   }
	
	public boolean authenticate(String email, String password){
		for(User user:users)
			if (user.getEmail().equals(email) && 
                                user.getPassword().equals(password))
				return true;
		
		return false;
	}
	
	public User getUser(String email){
		for(User u:users) if (u.getEmail().equals(email)) return u;
		return null;
	}
        
        public void addUser(String name, String email, String password) {
            User u = new User(name, email, password);
            EntityManager em = emf.createEntityManager();
            try {
                em.getTransaction().begin();
                em.persist(u);
                em.getTransaction().commit();
            } catch (Exception e) {
                em.getTransaction().rollback();
                em.close();
            }
        }
       
}
